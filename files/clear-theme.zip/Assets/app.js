"use strict;"
/*
 *  CSS
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.CSS = {
	name: "App.Components.Blocks.CSS",
	extends: Runtime.Component,
	methods:
	{
		getClassName: function(){ return "App.Components.Blocks.CSS"; },
	},
	getComponentStyle: function(){ return ":root{--widget-font-family: Arial;--widget-font-size: 16px;--widget-color-link: blue}body, html{font-family: var(--widget-font-family);font-size: var(--widget-font-size);line-height: var(--widget-line-height);width: 100%;padding: 0;margin: 0}.page_title{font-size: 32px;margin: 0px;text-align: center}%(TextArea)widget_textarea{min-height: 200px}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Button", "Runtime.Widget.Form.Form", "Runtime.Widget.TextArea"); },
};
window["App.Components.Blocks.CSS"] = App.Components.Blocks.CSS;
"use strict;"
/*
 *  Fonts
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.Fonts = {
	name: "App.Components.Blocks.Fonts",
	extends: Runtime.Component,
	methods:
	{
		getClassName: function(){ return "App.Components.Blocks.Fonts"; },
	},
	getComponentStyle: function(){ return ""; },
	getRequiredComponents: function(){ return new Runtime.Vector(); },
};
window["App.Components.Blocks.Fonts"] = App.Components.Blocks.Fonts;
"use strict;"
/*
 *  Footer
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.Footer = {
	name: "App.Components.Blocks.Footer",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div");
			
			/* Element Runtime.Widget.Section */
			let __v1 = __v0.element("Runtime.Widget.Section", new Runtime.Map({"class": rs.className(["footer", this.class, componentHash])}));
			
			/* Content */
			__v1.slot("default", () =>
			{
				const rs = use("Runtime.rs");
				const componentHash = rs.getComponentHash(this.getClassName());
				let __v = new Runtime.VirtualDom(this);
				__v.push("            Footer\n        ");
				return __v;
			});
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Blocks.Footer"; },
	},
	getComponentStyle: function(){ return ".footer.h-3969{background-position: center top;background-repeat: no-repeat;background-size: cover;padding-top: 10px}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Section"); },
};
window["App.Components.Blocks.Footer"] = App.Components.Blocks.Footer;
"use strict;"
/*
 *  Header
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.Header = {
	name: "App.Components.Blocks.Header",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div");
			
			/* Element Runtime.Widget.Section */
			let __v1 = __v0.element("Runtime.Widget.Section", new Runtime.Map({"class": rs.className(["header", this.class, componentHash])}));
			
			/* Content */
			__v1.slot("default", () =>
			{
				const rs = use("Runtime.rs");
				const componentHash = rs.getComponentHash(this.getClassName());
				let __v = new Runtime.VirtualDom(this);
				__v.push("            Header\n        ");
				return __v;
			});
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Blocks.Header"; },
	},
	getComponentStyle: function(){ return ".header.h-944f{background-position: center top;background-repeat: no-repeat;background-size: cover;padding-top: 10px}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Section"); },
};
window["App.Components.Blocks.Header"] = App.Components.Blocks.Header;
"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Layout == 'undefined') App.Components.Layout = {};
App.Components.Layout.DefaultLayout = {
	name: "App.Components.Layout.DefaultLayout",
	extends: Runtime.DefaultLayout,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div", new Runtime.Map({"class": rs.className(["layout_default", componentHash])}));
			
			/* Element App.Components.Blocks.Header */
			__v0.element("App.Components.Blocks.Header");
			
			/* Element div */
			let __v1 = __v0.element("div", new Runtime.Map({"class": rs.className(["layout_content", componentHash])}));
			__v1.push(this.renderCurrentPage());
			
			/* Element App.Components.Blocks.Footer */
			__v0.element("App.Components.Blocks.Footer");
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Layout.DefaultLayout"; },
	},
	getComponentStyle: function(){ return ""; },
	getRequiredComponents: function(){ return new Runtime.Vector("App.Components.Blocks.Footer", "App.Components.Blocks.Header"); },
};
window["App.Components.Layout.DefaultLayout"] = App.Components.Layout.DefaultLayout;
"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Layout == 'undefined') App.Components.Layout = {};
App.Components.Layout.DefaultLayoutModel = class extends Runtime.BaseLayout
{
	/**
	 * Process frontend data
	 */
	serialize(serializer)
	{
		super.serialize(serializer);
	}
	
	
	/**
	 * Load data
	 */
	async loadData(container)
	{
		super.loadData(container);
	}
	
	
	/* ========= Class init functions ========= */
	_init()
	{
		super._init();
		this.component = "App.Components.Layout.DefaultLayout";
	}
	static getClassName(){ return "App.Components.Layout.DefaultLayoutModel"; }
	static getMethodsList(){ return null; }
	static getMethodInfoByName(field_name){ return null; }
	static getInterfaces(){ return []; }
};
window["App.Components.Layout.DefaultLayoutModel"] = App.Components.Layout.DefaultLayoutModel;
"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
if (typeof App.Components.Pages.IndexPage == 'undefined') App.Components.Pages.IndexPage = {};
App.Components.Pages.IndexPage.IndexPage = {
	name: "App.Components.Pages.IndexPage.IndexPage",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div", new Runtime.Map({"class": rs.className(["main_page", componentHash])}));
			
			/* Element Runtime.Widget.Section */
			let __v1 = __v0.element("Runtime.Widget.Section", new Runtime.Map({"class": rs.className(["main_section", componentHash])}));
			
			/* Content */
			__v1.slot("default", () =>
			{
				const rs = use("Runtime.rs");
				const componentHash = rs.getComponentHash(this.getClassName());
				let __v = new Runtime.VirtualDom(this);
				
				/* Element h1 */
				let __v0 = __v.element("h1", new Runtime.Map({"class": rs.className(["page_title", componentHash])}));
				__v0.push("Index page");
				
				/* Element div */
				let __v1 = __v.element("div", new Runtime.Map({"class": rs.className(["page_text", componentHash])}));
				__v1.push("Clear project");
				
				return __v;
			});
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Pages.IndexPage.IndexPage"; },
	},
	getComponentStyle: function(){ return ".main_section.h-8c96{padding-top: 20px;padding-bottom: 20px;background-position: center top;background-repeat: no-repeat;background-size: cover}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Section", "Runtime.Widget.Text"); },
};
window["App.Components.Pages.IndexPage.IndexPage"] = App.Components.Pages.IndexPage.IndexPage;
"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
if (typeof App.Components.Pages.IndexPage == 'undefined') App.Components.Pages.IndexPage = {};
App.Components.Pages.IndexPage.IndexPageModel = class extends Runtime.BaseModel
{
	/**
	 * Init widget
	 */
	initWidget(params)
	{
		super.initWidget(params);
	}
	
	
	/**
	 * Build title
	 */
	buildTitle(container)
	{
		this.layout.setPageTitle("Index page");
	}
	
	
	/* ========= Class init functions ========= */
	_init()
	{
		super._init();
		this.component = "App.Components.Pages.IndexPage.IndexPage";
	}
	static getClassName(){ return "App.Components.Pages.IndexPage.IndexPageModel"; }
	static getMethodsList(){ return null; }
	static getMethodInfoByName(field_name){ return null; }
	static getInterfaces(){ return []; }
};
window["App.Components.Pages.IndexPage.IndexPageModel"] = App.Components.Pages.IndexPage.IndexPageModel;
"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
if (typeof App.Components.Pages.NotFoundPage == 'undefined') App.Components.Pages.NotFoundPage = {};
App.Components.Pages.NotFoundPage.NotFoundPage = {
	name: "App.Components.Pages.NotFoundPage.NotFoundPage",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div", new Runtime.Map({"class": rs.className(["not_found_page", componentHash])}));
			
			/* Element Runtime.Widget.Text */
			__v0.element("Runtime.Widget.Text", new Runtime.Map({"content": "Страница не найдена", "class": rs.className(["text_not_found", componentHash])}));
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Pages.NotFoundPage.NotFoundPage"; },
	},
	getComponentStyle: function(){ return ".text_not_found.h-ee64{font-size: 150%;font-weight: bold;text-align: center;padding-top: 20px;padding-bottom: 20px}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Text"); },
};
window["App.Components.Pages.NotFoundPage.NotFoundPage"] = App.Components.Pages.NotFoundPage.NotFoundPage;
"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
if (typeof App.Components.Pages.NotFoundPage == 'undefined') App.Components.Pages.NotFoundPage = {};
App.Components.Pages.NotFoundPage.NotFoundPageModel = class extends Runtime.BaseModel
{
	/**
	 * Build title
	 */
	buildTitle(container)
	{
		/* Set title */
		this.layout.setPageTitle("Page not found");
		/* Setup 404 response */
		container.http_code = 404;
	}
	
	
	/* ========= Class init functions ========= */
	_init()
	{
		super._init();
		this.component = "App.Components.Pages.NotFoundPage.NotFoundPage";
	}
	static getClassName(){ return "App.Components.Pages.NotFoundPage.NotFoundPageModel"; }
	static getMethodsList(){ return null; }
	static getMethodInfoByName(field_name){ return null; }
	static getInterfaces(){ return []; }
};
window["App.Components.Pages.NotFoundPage.NotFoundPageModel"] = App.Components.Pages.NotFoundPage.NotFoundPageModel;
"use strict;"
/*
 *  ThankYouPage
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
App.Components.Pages.ThankYouPage = {
	name: "App.Components.Pages.ThankYouPage",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div");
			
			/* Element div */
			let __v1 = __v0.element("div", new Runtime.Map({"class": rs.className(["thank_you_page", componentHash])}));
			
			/* Element h1 */
			let __v2 = __v1.element("h1", new Runtime.Map({"class": rs.className(["page_title", componentHash])}));
			__v2.push("Ваше сообщение успешно отправлено");
			
			/* Element div */
			let __v3 = __v1.element("div", new Runtime.Map({"class": rs.className(["message", componentHash])}));
			__v3.push("Ожидайте, мы свяжемся с вами");
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Pages.ThankYouPage"; },
	},
	getComponentStyle: function(){ return ".thank_you_page.h-1e81{text-align: center;font-size: 16px;padding-top: 100px}.page_title.h-1e81{line-height: 1.2}.message.h-1e81{margin: 0;margin-top: 1em;margin-bottom: 1em}"; },
	getRequiredComponents: function(){ return new Runtime.Vector(); },
};
window["App.Components.Pages.ThankYouPage"] = App.Components.Pages.ThankYouPage;
"use strict;"
if (typeof App == 'undefined') App = {};
App.ModuleDescription = class
{
	/**
	 * Returns module name
	 */
	static getModuleName(){ return "App"; }
	
	
	/**
	 * Returns module version
	 */
	static getModuleVersion(){ return "0.0.1"; }
	
	
	/**
	 * Returns required modules
	 * @return Map<string>
	 */
	static requiredModules()
	{
		return Runtime.Map.create({
			"Runtime.Web": "*",
			"Runtime.Widget": "*",
		});
	}
	
	
	/**
	 * Returns enities
	 */
	static entities()
	{
		return Runtime.Vector.create([
			Runtime.Web.Hooks.SetupLayout.hook(Runtime.Map.create({
				"default": "App.Components.Layout.DefaultLayoutModel",
			})),
			Runtime.Web.Hooks.Components.hook(Runtime.Vector.create([
				"App.Components.Blocks.CSS",
				"App.Components.Blocks.Fonts",
			])),
			Runtime.Web.Hooks.Components.header(Runtime.Vector.create([
			])),
			Runtime.Web.Hooks.Components.footer(Runtime.Vector.create([
				"App.Components.Blocks.Metrika",
			])),
			Runtime.Web.Hooks.PageNotFound.hook("App.Components.Pages.NotFoundPage.NotFoundPageModel"),
		]);
	}
	
	
	/* ========= Class init functions ========= */
	_init()
	{
	}
	static getClassName(){ return "App.ModuleDescription"; }
	static getMethodsList(){ return null; }
	static getMethodInfoByName(field_name){ return null; }
	static getInterfaces(){ return []; }
};
window["App.ModuleDescription"] = App.ModuleDescription;
