"use strict;"
if (typeof App == 'undefined') App = {};
App.ModuleDescription = class
{
	/**
	 * Returns module name
	 */
	static getModuleName(){ return "App"; }
	
	
	/**
	 * Returns module version
	 */
	static getModuleVersion(){ return "0.0.1"; }
	
	
	/**
	 * Returns required modules
	 * @return Map<string>
	 */
	static requiredModules()
	{
		return Runtime.Map.create({
			"Runtime.Web": "*",
			"Runtime.Widget": "*",
		});
	}
	
	
	/**
	 * Returns enities
	 */
	static entities()
	{
		return Runtime.Vector.create([
			Runtime.Web.Hooks.SetupLayout.hook(Runtime.Map.create({
				"default": "App.Components.Layout.DefaultLayoutModel",
			})),
			Runtime.Web.Hooks.Components.hook(Runtime.Vector.create([
				"App.Components.Blocks.CSS",
				"App.Components.Blocks.Fonts",
			])),
			Runtime.Web.Hooks.Components.header(Runtime.Vector.create([
			])),
			Runtime.Web.Hooks.Components.footer(Runtime.Vector.create([
				"App.Components.Blocks.Metrika",
			])),
			Runtime.Web.Hooks.PageNotFound.hook("App.Components.Pages.NotFoundPage.NotFoundPageModel"),
		]);
	}
	
	
	/* ========= Class init functions ========= */
	_init()
	{
	}
	static getClassName(){ return "App.ModuleDescription"; }
	static getMethodsList(){ return null; }
	static getMethodInfoByName(field_name){ return null; }
	static getInterfaces(){ return []; }
};
window["App.ModuleDescription"] = App.ModuleDescription;