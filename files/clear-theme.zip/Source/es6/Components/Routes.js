"use strict;"
/*!
 *  Routes
 */
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
App.Components.Routes = class extends Runtime.Web.BaseRoute
{
	/**
	 * Returns layout name
	 */
	static getLayoutName(){ return "default"; }
	
	
	/**
	 * Returns routes
	 */
	static getRoutes()
	{
		return Runtime.Vector.create([
			new Runtime.Web.RouteModel(Runtime.Map.create({
				"uri": "/",
				"name": "app:index",
				"model": "App.Components.Pages.IndexPage.IndexPageModel",
			})),
			new Runtime.Web.RoutePage(Runtime.Map.create({
				"uri": "/thank-you.html",
				"name": "app:thank_you_page",
				"page": "App.Components.Pages.ThankYouPage",
				"data": Runtime.Map.create({
					"title": "Ваше сообщение успешно отправлено",
					"robots": Runtime.Vector.create(["nofollow", "noindex"]),
				}),
			})),
		]);
	}
	
	
	/* ========= Class init functions ========= */
	_init()
	{
		super._init();
	}
	static getClassName(){ return "App.Components.Routes"; }
	static getMethodsList(){ return null; }
	static getMethodInfoByName(field_name){ return null; }
	static getInterfaces(){ return []; }
};
window["App.Components.Routes"] = App.Components.Routes;