"use strict;"
/*
 *  ThankYouPage
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
App.Components.Pages.ThankYouPage = {
	name: "App.Components.Pages.ThankYouPage",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div");
			
			/* Element div */
			let __v1 = __v0.element("div", new Runtime.Map({"class": rs.className(["thank_you_page", componentHash])}));
			
			/* Element h1 */
			let __v2 = __v1.element("h1", new Runtime.Map({"class": rs.className(["page_title", componentHash])}));
			__v2.push("Ваше сообщение успешно отправлено");
			
			/* Element div */
			let __v3 = __v1.element("div", new Runtime.Map({"class": rs.className(["message", componentHash])}));
			__v3.push("Ожидайте, мы свяжемся с вами");
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Pages.ThankYouPage"; },
	},
	getComponentStyle: function(){ return ".thank_you_page.h-1e81{text-align: center;font-size: 16px;padding-top: 100px}.page_title.h-1e81{line-height: 1.2}.message.h-1e81{margin: 0;margin-top: 1em;margin-bottom: 1em}"; },
	getRequiredComponents: function(){ return new Runtime.Vector(); },
};
window["App.Components.Pages.ThankYouPage"] = App.Components.Pages.ThankYouPage;