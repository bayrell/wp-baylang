"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
if (typeof App.Components.Pages.IndexPage == 'undefined') App.Components.Pages.IndexPage = {};
App.Components.Pages.IndexPage.IndexPage = {
	name: "App.Components.Pages.IndexPage.IndexPage",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div", new Runtime.Map({"class": rs.className(["main_page", componentHash])}));
			
			/* Element Runtime.Widget.Section */
			let __v1 = __v0.element("Runtime.Widget.Section", new Runtime.Map({"class": rs.className(["main_section", componentHash])}));
			
			/* Content */
			__v1.slot("default", () =>
			{
				const rs = use("Runtime.rs");
				const componentHash = rs.getComponentHash(this.getClassName());
				let __v = new Runtime.VirtualDom(this);
				
				/* Element h1 */
				let __v0 = __v.element("h1", new Runtime.Map({"class": rs.className(["page_title", componentHash])}));
				__v0.push("Index page");
				
				/* Element div */
				let __v1 = __v.element("div", new Runtime.Map({"class": rs.className(["page_text", componentHash])}));
				__v1.push("Clear project");
				
				return __v;
			});
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Pages.IndexPage.IndexPage"; },
	},
	getComponentStyle: function(){ return ".main_section.h-8c96{padding-top: 20px;padding-bottom: 20px;background-position: center top;background-repeat: no-repeat;background-size: cover}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Section", "Runtime.Widget.Text"); },
};
window["App.Components.Pages.IndexPage.IndexPage"] = App.Components.Pages.IndexPage.IndexPage;