"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
if (typeof App.Components.Pages.IndexPage == 'undefined') App.Components.Pages.IndexPage = {};
App.Components.Pages.IndexPage.IndexPageModel = class extends Runtime.BaseModel
{
	/**
	 * Init widget
	 */
	initWidget(params)
	{
		super.initWidget(params);
	}
	
	
	/**
	 * Build title
	 */
	buildTitle(container)
	{
		this.layout.setPageTitle("Index page");
	}
	
	
	/* ========= Class init functions ========= */
	_init()
	{
		super._init();
		this.component = "App.Components.Pages.IndexPage.IndexPage";
	}
	static getClassName(){ return "App.Components.Pages.IndexPage.IndexPageModel"; }
	static getMethodsList(){ return null; }
	static getMethodInfoByName(field_name){ return null; }
	static getInterfaces(){ return []; }
};
window["App.Components.Pages.IndexPage.IndexPageModel"] = App.Components.Pages.IndexPage.IndexPageModel;