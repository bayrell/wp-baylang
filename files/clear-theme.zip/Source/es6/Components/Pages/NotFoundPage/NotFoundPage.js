"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
if (typeof App.Components.Pages.NotFoundPage == 'undefined') App.Components.Pages.NotFoundPage = {};
App.Components.Pages.NotFoundPage.NotFoundPage = {
	name: "App.Components.Pages.NotFoundPage.NotFoundPage",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div", new Runtime.Map({"class": rs.className(["not_found_page", componentHash])}));
			
			/* Element Runtime.Widget.Text */
			__v0.element("Runtime.Widget.Text", new Runtime.Map({"content": "Страница не найдена", "class": rs.className(["text_not_found", componentHash])}));
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Pages.NotFoundPage.NotFoundPage"; },
	},
	getComponentStyle: function(){ return ".text_not_found.h-ee64{font-size: 150%;font-weight: bold;text-align: center;padding-top: 20px;padding-bottom: 20px}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Text"); },
};
window["App.Components.Pages.NotFoundPage.NotFoundPage"] = App.Components.Pages.NotFoundPage.NotFoundPage;