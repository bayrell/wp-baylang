"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Pages == 'undefined') App.Components.Pages = {};
if (typeof App.Components.Pages.NotFoundPage == 'undefined') App.Components.Pages.NotFoundPage = {};
App.Components.Pages.NotFoundPage.NotFoundPageModel = class extends Runtime.BaseModel
{
	/**
	 * Build title
	 */
	buildTitle(container)
	{
		/* Set title */
		this.layout.setPageTitle("Page not found");
		/* Setup 404 response */
		container.http_code = 404;
	}
	
	
	/* ========= Class init functions ========= */
	_init()
	{
		super._init();
		this.component = "App.Components.Pages.NotFoundPage.NotFoundPage";
	}
	static getClassName(){ return "App.Components.Pages.NotFoundPage.NotFoundPageModel"; }
	static getMethodsList(){ return null; }
	static getMethodInfoByName(field_name){ return null; }
	static getInterfaces(){ return []; }
};
window["App.Components.Pages.NotFoundPage.NotFoundPageModel"] = App.Components.Pages.NotFoundPage.NotFoundPageModel;