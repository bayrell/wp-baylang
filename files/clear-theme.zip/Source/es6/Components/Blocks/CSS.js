"use strict;"
/*
 *  CSS
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.CSS = {
	name: "App.Components.Blocks.CSS",
	extends: Runtime.Component,
	methods:
	{
		getClassName: function(){ return "App.Components.Blocks.CSS"; },
	},
	getComponentStyle: function(){ return ":root{--widget-font-family: Arial;--widget-font-size: 16px;--widget-color-link: blue}body, html{font-family: var(--widget-font-family);font-size: var(--widget-font-size);line-height: var(--widget-line-height);width: 100%;padding: 0;margin: 0}.page_title{font-size: 32px;margin: 0px;text-align: center}%(TextArea)widget_textarea{min-height: 200px}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Button", "Runtime.Widget.Form.Form", "Runtime.Widget.TextArea"); },
};
window["App.Components.Blocks.CSS"] = App.Components.Blocks.CSS;