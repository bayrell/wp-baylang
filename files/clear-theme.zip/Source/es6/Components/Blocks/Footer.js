"use strict;"
/*
 *  Footer
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.Footer = {
	name: "App.Components.Blocks.Footer",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div");
			
			/* Element Runtime.Widget.Section */
			let __v1 = __v0.element("Runtime.Widget.Section", new Runtime.Map({"class": rs.className(["footer", this.class, componentHash])}));
			
			/* Content */
			__v1.slot("default", () =>
			{
				const rs = use("Runtime.rs");
				const componentHash = rs.getComponentHash(this.getClassName());
				let __v = new Runtime.VirtualDom(this);
				__v.push("            Footer\n        ");
				return __v;
			});
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Blocks.Footer"; },
	},
	getComponentStyle: function(){ return ".footer.h-3969{background-position: center top;background-repeat: no-repeat;background-size: cover;padding-top: 10px}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Section"); },
};
window["App.Components.Blocks.Footer"] = App.Components.Blocks.Footer;