"use strict;"
/*
 *  Metrika
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.Metrika = {
	name: "App.Components.Blocks.Metrika",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			if (Runtime.rtl.getContext().env("METRIKA_ENABLED"))
			{
			}
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Blocks.Metrika"; },
	},
	getComponentStyle: function(){ return ""; },
	getRequiredComponents: function(){ return new Runtime.Vector(); },
};
window["App.Components.Blocks.Metrika"] = App.Components.Blocks.Metrika;