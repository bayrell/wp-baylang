"use strict;"
/*
 *  Header
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.Header = {
	name: "App.Components.Blocks.Header",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div");
			
			/* Element Runtime.Widget.Section */
			let __v1 = __v0.element("Runtime.Widget.Section", new Runtime.Map({"class": rs.className(["header", this.class, componentHash])}));
			
			/* Content */
			__v1.slot("default", () =>
			{
				const rs = use("Runtime.rs");
				const componentHash = rs.getComponentHash(this.getClassName());
				let __v = new Runtime.VirtualDom(this);
				__v.push("            Header\n        ");
				return __v;
			});
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Blocks.Header"; },
	},
	getComponentStyle: function(){ return ".header.h-944f{background-position: center top;background-repeat: no-repeat;background-size: cover;padding-top: 10px}"; },
	getRequiredComponents: function(){ return new Runtime.Vector("Runtime.Widget.Section"); },
};
window["App.Components.Blocks.Header"] = App.Components.Blocks.Header;