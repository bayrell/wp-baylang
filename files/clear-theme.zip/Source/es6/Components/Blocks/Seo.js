"use strict;"
/*
 *  Seo
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.Seo = {
	name: "App.Components.Blocks.Seo",
	extends: Runtime.Component,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element title */
			let __v0 = __v.element("title");
			__v0.push(this.layout.getFullTitle());
			
			/* Element meta */
			__v.element("meta", new Runtime.Map({"charset": this.layout.content_type}));
			
			/* Element meta */
			__v.element("meta", new Runtime.Map({"http-equiv": "Content-Type", "content": "text/html; " + String(this.layout.content_type)}));
			
			/* Element meta */
			__v.element("meta", new Runtime.Map({"http-equiv": "Content-Language", "content": this.layout.getLocale()}));
			
			/* Element meta */
			__v.element("meta", new Runtime.Map({"http-equiv": "X-UA-Compatible", "content": "IE=edge"}));
			
			/* Element meta */
			__v.element("meta", new Runtime.Map({"name": "viewport", "content": "width=device-width, initial-scale=1"}));
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Blocks.Seo"; },
	},
	getComponentStyle: function(){ return ""; },
	getRequiredComponents: function(){ return new Runtime.Vector(); },
};
window["App.Components.Blocks.Seo"] = App.Components.Blocks.Seo;