"use strict;"
/*
 *  Fonts
*/
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Blocks == 'undefined') App.Components.Blocks = {};
App.Components.Blocks.Fonts = {
	name: "App.Components.Blocks.Fonts",
	extends: Runtime.Component,
	methods:
	{
		getClassName: function(){ return "App.Components.Blocks.Fonts"; },
	},
	getComponentStyle: function(){ return ""; },
	getRequiredComponents: function(){ return new Runtime.Vector(); },
};
window["App.Components.Blocks.Fonts"] = App.Components.Blocks.Fonts;