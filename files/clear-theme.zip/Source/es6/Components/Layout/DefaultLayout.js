"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Layout == 'undefined') App.Components.Layout = {};
App.Components.Layout.DefaultLayout = {
	name: "App.Components.Layout.DefaultLayout",
	extends: Runtime.DefaultLayout,
	methods:
	{
		render: function()
		{
			const rs = use("Runtime.rs");
			const componentHash = rs.getComponentHash(this.getClassName());
			let __v = new Runtime.VirtualDom(this);
			
			/* Element div */
			let __v0 = __v.element("div", new Runtime.Map({"class": rs.className(["layout_default", componentHash])}));
			
			/* Element App.Components.Blocks.Header */
			__v0.element("App.Components.Blocks.Header");
			
			/* Element div */
			let __v1 = __v0.element("div", new Runtime.Map({"class": rs.className(["layout_content", componentHash])}));
			__v1.push(this.renderCurrentPage());
			
			/* Element App.Components.Blocks.Footer */
			__v0.element("App.Components.Blocks.Footer");
			
			return __v;
		},
		getClassName: function(){ return "App.Components.Layout.DefaultLayout"; },
	},
	getComponentStyle: function(){ return ""; },
	getRequiredComponents: function(){ return new Runtime.Vector("App.Components.Blocks.Footer", "App.Components.Blocks.Header"); },
};
window["App.Components.Layout.DefaultLayout"] = App.Components.Layout.DefaultLayout;