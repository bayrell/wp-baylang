"use strict;"
if (typeof App == 'undefined') App = {};
if (typeof App.Components == 'undefined') App.Components = {};
if (typeof App.Components.Layout == 'undefined') App.Components.Layout = {};
App.Components.Layout.DefaultLayoutModel = class extends Runtime.BaseLayout
{
	/**
	 * Process frontend data
	 */
	serialize(serializer)
	{
		super.serialize(serializer);
	}
	
	
	/**
	 * Load data
	 */
	async loadData(container)
	{
		super.loadData(container);
	}
	
	
	/* ========= Class init functions ========= */
	_init()
	{
		super._init();
		this.component = "App.Components.Layout.DefaultLayout";
	}
	static getClassName(){ return "App.Components.Layout.DefaultLayoutModel"; }
	static getMethodsList(){ return null; }
	static getMethodInfoByName(field_name){ return null; }
	static getInterfaces(){ return []; }
};
window["App.Components.Layout.DefaultLayoutModel"] = App.Components.Layout.DefaultLayoutModel;