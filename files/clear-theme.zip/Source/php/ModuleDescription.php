<?php
namespace App;

use Runtime\Entity\Hook;
use Runtime\Web\Annotations\Route;
use Runtime\Web\Hooks\PageNotFound;
use Runtime\Web\Hooks\Components;
use Runtime\Web\Hooks\SetupLayout;


class ModuleDescription
{
	/**
	 * Returns module name
	 */
	static function getModuleName(){ return "App"; }
	
	
	/**
	 * Returns module version
	 */
	static function getModuleVersion(){ return "0.0.1"; }
	
	
	/**
	 * Returns required modules
	 * @return Map<string>
	 */
	static function requiredModules()
	{
		return new \Runtime\Map([
			"Runtime.Web" => "*",
			"Runtime.Widget" => "*",
		]);
	}
	
	
	/**
	 * Returns enities
	 */
	static function entities()
	{
		return new \Runtime\Vector(
			\Runtime\Web\Hooks\SetupLayout::hook(new \Runtime\Map([
				"default" => "App.Components.Layout.DefaultLayoutModel",
			])),
			\Runtime\Web\Hooks\Components::hook(new \Runtime\Vector(
				"App.Components.Blocks.CSS",
				"App.Components.Blocks.Fonts",
			)),
			\Runtime\Web\Hooks\Components::header(new \Runtime\Vector(
			)),
			\Runtime\Web\Hooks\Components::footer(new \Runtime\Vector(
				"App.Components.Blocks.Metrika",
			)),
			\Runtime\Web\Hooks\PageNotFound::hook("App.Components.Pages.NotFoundPage.NotFoundPageModel"),
			new \Runtime\Web\Annotations\Route("App.Components.Routes"),
		);
	}
	
	
	/* ========= Class init functions ========= */
	function _init()
	{
	}
	static function getClassName(){ return "App.ModuleDescription"; }
	static function getMethodsList(){ return null; }
	static function getMethodInfoByName($field_name){ return null; }
}