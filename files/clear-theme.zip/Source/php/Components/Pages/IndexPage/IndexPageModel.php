<?php
namespace App\Components\Pages\IndexPage;

use Runtime\Entity\Factory;
use Runtime\BaseModel;
use Runtime\Web\RenderContainer;
use App\Components\Pages\IndexPage\IndexPage;


class IndexPageModel extends \Runtime\BaseModel
{
	var $component;
	
	
	/**
	 * Init widget
	 */
	function initWidget($params)
	{
		parent::initWidget($params);
	}
	
	
	/**
	 * Build title
	 */
	function buildTitle($container)
	{
		$this->layout->setPageTitle("Index page");
	}
	
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
		$this->component = "App.Components.Pages.IndexPage.IndexPage";
	}
	static function getClassName(){ return "App.Components.Pages.IndexPage.IndexPageModel"; }
	static function getMethodsList(){ return null; }
	static function getMethodInfoByName($field_name){ return null; }
}