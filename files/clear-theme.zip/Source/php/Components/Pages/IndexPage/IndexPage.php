<?php
namespace App\Components\Pages\IndexPage;

use Runtime\Widget\Section;
use Runtime\Widget\Text;


class IndexPage extends \Runtime\Component
{
	function render()
	{
		$componentHash = \Runtime\rs::getComponentHash(static::getClassName());
		$__v = new \Runtime\VirtualDom($this);
		$__v->is_render = true;
		
		/* Element div */
		$__v0 = $__v->element("div", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("main_page", $componentHash))])));
		
		/* Element Runtime.Widget.Section */
		$__v1 = $__v0->element("Runtime.Widget.Section", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("main_section", $componentHash))])));
		
		/* Content */
		$__v1->slot("default", function ()
		{
			$componentHash = \Runtime\rs::getComponentHash(static::getClassName());
			$__v = new \Runtime\VirtualDom($this);
			
			/* Element h1 */
			$__v0 = $__v->element("h1", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("page_title", $componentHash))])));
			$__v0->push("Index page");
			
			/* Element div */
			$__v1 = $__v->element("div", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("page_text", $componentHash))])));
			$__v1->push("Clear project");
			
			return $__v;
		});
		
		return $__v;
	}
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getComponentStyle(){ return ".main_section.h-8c96{padding-top: 20px;padding-bottom: 20px;background-position: center top;background-repeat: no-repeat;background-size: cover}"; }
	static function getRequiredComponents(){ return new \Runtime\Vector("Runtime.Widget.Section", "Runtime.Widget.Text"); }
	static function getClassName(){ return "App.Components.Pages.IndexPage.IndexPage"; }
}