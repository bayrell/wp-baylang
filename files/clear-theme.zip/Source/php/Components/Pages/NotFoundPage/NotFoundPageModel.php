<?php
namespace App\Components\Pages\NotFoundPage;

use Runtime\BaseModel;
use Runtime\Web\RenderContainer;
use App\Components\Pages\NotFoundPage\NotFoundPage;


class NotFoundPageModel extends \Runtime\BaseModel
{
	var $component;
	
	
	/**
	 * Build title
	 */
	function buildTitle($container)
	{
		/* Set title */
		$this->layout->setPageTitle("Page not found");
		/* Setup 404 response */
		$container->http_code = 404;
	}
	
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
		$this->component = "App.Components.Pages.NotFoundPage.NotFoundPage";
	}
	static function getClassName(){ return "App.Components.Pages.NotFoundPage.NotFoundPageModel"; }
	static function getMethodsList(){ return null; }
	static function getMethodInfoByName($field_name){ return null; }
}