<?php
namespace App\Components\Pages\NotFoundPage;

use Runtime\Widget\Text;

class NotFoundPage extends \Runtime\Component
{
	function render()
	{
		$componentHash = \Runtime\rs::getComponentHash(static::getClassName());
		$__v = new \Runtime\VirtualDom($this);
		$__v->is_render = true;
		
		/* Element div */
		$__v0 = $__v->element("div", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("not_found_page", $componentHash))])));
		
		/* Element Runtime.Widget.Text */
		$__v0->element("Runtime.Widget.Text", (new \Runtime\Map(["content" => "Страница не найдена", "class" => \Runtime\rs::className(new \Runtime\Vector("text_not_found", $componentHash))])));
		
		return $__v;
	}
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getComponentStyle(){ return ".text_not_found.h-ee64{font-size: 150%;font-weight: bold;text-align: center;padding-top: 20px;padding-bottom: 20px}"; }
	static function getRequiredComponents(){ return new \Runtime\Vector("Runtime.Widget.Text"); }
	static function getClassName(){ return "App.Components.Pages.NotFoundPage.NotFoundPage"; }
}