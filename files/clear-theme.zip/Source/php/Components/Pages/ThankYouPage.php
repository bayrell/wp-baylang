<?php
/*
 *  ThankYouPage
*/
namespace App\Components\Pages;


class ThankYouPage extends \Runtime\Component
{
	function render()
	{
		$componentHash = \Runtime\rs::getComponentHash(static::getClassName());
		$__v = new \Runtime\VirtualDom($this);
		$__v->is_render = true;
		
		/* Element div */
		$__v0 = $__v->element("div");
		
		/* Element div */
		$__v1 = $__v0->element("div", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("thank_you_page", $componentHash))])));
		
		/* Element h1 */
		$__v2 = $__v1->element("h1", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("page_title", $componentHash))])));
		$__v2->push("Ваше сообщение успешно отправлено");
		
		/* Element div */
		$__v3 = $__v1->element("div", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("message", $componentHash))])));
		$__v3->push("Ожидайте, мы свяжемся с вами");
		
		return $__v;
	}
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getComponentStyle(){ return ".thank_you_page.h-1e81{text-align: center;font-size: 16px;padding-top: 100px}.page_title.h-1e81{line-height: 1.2}.message.h-1e81{margin: 0;margin-top: 1em;margin-bottom: 1em}"; }
	static function getRequiredComponents(){ return new \Runtime\Vector(); }
	static function getClassName(){ return "App.Components.Pages.ThankYouPage"; }
}