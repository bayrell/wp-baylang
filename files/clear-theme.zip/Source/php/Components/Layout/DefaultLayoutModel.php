<?php
namespace App\Components\Layout;

use Runtime\BaseLayout;
use Runtime\Serializer;
use Runtime\Web\RenderContainer;
use App\Components\Layout\DefaultLayout;


class DefaultLayoutModel extends \Runtime\BaseLayout
{
	var $component;
	
	
	/**
	 * Process frontend data
	 */
	function serialize($serializer)
	{
		parent::serialize($serializer);
	}
	
	
	/**
	 * Load data
	 */
	function loadData($container)
	{
		parent::loadData($container);
	}
	
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
		$this->component = "App.Components.Layout.DefaultLayout";
	}
	static function getClassName(){ return "App.Components.Layout.DefaultLayoutModel"; }
	static function getMethodsList(){ return null; }
	static function getMethodInfoByName($field_name){ return null; }
}