<?php
namespace App\Components\Layout;

use App\Components\Blocks\Footer;
use App\Components\Blocks\Header;


class DefaultLayout extends \Runtime\DefaultLayout
{
	function render()
	{
		$componentHash = \Runtime\rs::getComponentHash(static::getClassName());
		$__v = new \Runtime\VirtualDom($this);
		$__v->is_render = true;
		
		/* Element div */
		$__v0 = $__v->element("div", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("layout_default", $componentHash))])));
		
		/* Element App.Components.Blocks.Header */
		$__v0->element("App.Components.Blocks.Header");
		
		/* Element div */
		$__v1 = $__v0->element("div", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("layout_content", $componentHash))])));
		$__v1->push($this->renderCurrentPage());
		
		/* Element App.Components.Blocks.Footer */
		$__v0->element("App.Components.Blocks.Footer");
		
		return $__v;
	}
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getComponentStyle(){ return ""; }
	static function getRequiredComponents(){ return new \Runtime\Vector("App.Components.Blocks.Footer", "App.Components.Blocks.Header"); }
	static function getClassName(){ return "App.Components.Layout.DefaultLayout"; }
}