<?php
/*!
 *  Routes
 */
namespace App\Components;

use Runtime\Web\BaseRoute;
use Runtime\Web\RouteInfo;
use Runtime\Web\RouteModel;
use Runtime\Web\RoutePage;


class Routes extends \Runtime\Web\BaseRoute
{
	/**
	 * Returns layout name
	 */
	static function getLayoutName(){ return "default"; }
	
	
	/**
	 * Returns routes
	 */
	static function getRoutes()
	{
		return new \Runtime\Vector(
			new \Runtime\Web\RouteModel(new \Runtime\Map([
				"uri" => "/",
				"name" => "app:index",
				"model" => "App.Components.Pages.IndexPage.IndexPageModel",
			])),
			new \Runtime\Web\RoutePage(new \Runtime\Map([
				"uri" => "/thank-you.html",
				"name" => "app:thank_you_page",
				"page" => "App.Components.Pages.ThankYouPage",
				"data" => new \Runtime\Map([
					"title" => "Ваше сообщение успешно отправлено",
					"robots" => new \Runtime\Vector("nofollow", "noindex"),
				]),
			])),
		);
	}
	
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getClassName(){ return "App.Components.Routes"; }
	static function getMethodsList(){ return null; }
	static function getMethodInfoByName($field_name){ return null; }
}