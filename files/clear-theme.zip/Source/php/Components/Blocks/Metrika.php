<?php
/*
 *  Metrika
*/
namespace App\Components\Blocks;


class Metrika extends \Runtime\Component
{
	function render()
	{
		$componentHash = \Runtime\rs::getComponentHash(static::getClassName());
		$__v = new \Runtime\VirtualDom($this);
		$__v->is_render = true;
		
		if (\Runtime\rtl::getContext()->env("METRIKA_ENABLED"))
		{
		}
		
		return $__v;
	}
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getComponentStyle(){ return ""; }
	static function getRequiredComponents(){ return new \Runtime\Vector(); }
	static function getClassName(){ return "App.Components.Blocks.Metrika"; }
}