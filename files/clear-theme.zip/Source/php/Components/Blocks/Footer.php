<?php
/*
 *  Footer
*/
namespace App\Components\Blocks;

use Runtime\Widget\Section;

class Footer extends \Runtime\Component
{
	function render()
	{
		$componentHash = \Runtime\rs::getComponentHash(static::getClassName());
		$__v = new \Runtime\VirtualDom($this);
		$__v->is_render = true;
		
		/* Element div */
		$__v0 = $__v->element("div");
		
		/* Element Runtime.Widget.Section */
		$__v1 = $__v0->element("Runtime.Widget.Section", (new \Runtime\Map(["class" => \Runtime\rs::className(new \Runtime\Vector("footer", $this->class, $componentHash))])));
		
		/* Content */
		$__v1->slot("default", function ()
		{
			$componentHash = \Runtime\rs::getComponentHash(static::getClassName());
			$__v = new \Runtime\VirtualDom($this);
			$__v->push("            Footer\n        ");
			return $__v;
		});
		
		return $__v;
	}
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getComponentStyle(){ return ".footer.h-3969{background-position: center top;background-repeat: no-repeat;background-size: cover;padding-top: 10px}"; }
	static function getRequiredComponents(){ return new \Runtime\Vector("Runtime.Widget.Section"); }
	static function getClassName(){ return "App.Components.Blocks.Footer"; }
}