<?php
/*
 *  Seo
*/
namespace App\Components\Blocks;


class Seo extends \Runtime\Component
{
	function render()
	{
		$componentHash = \Runtime\rs::getComponentHash(static::getClassName());
		$__v = new \Runtime\VirtualDom($this);
		$__v->is_render = true;
		
		/* Element title */
		$__v0 = $__v->element("title");
		$__v0->push($this->layout->getFullTitle());
		
		/* Element meta */
		$__v->element("meta", (new \Runtime\Map(["charset" => $this->layout->content_type])));
		
		/* Element meta */
		$__v->element("meta", (new \Runtime\Map(["http-equiv" => "Content-Type", "content" => "text/html; " . $this->layout->content_type])));
		
		/* Element meta */
		$__v->element("meta", (new \Runtime\Map(["http-equiv" => "Content-Language", "content" => $this->layout->getLocale()])));
		
		/* Element meta */
		$__v->element("meta", (new \Runtime\Map(["http-equiv" => "X-UA-Compatible", "content" => "IE=edge"])));
		
		/* Element meta */
		$__v->element("meta", (new \Runtime\Map(["name" => "viewport", "content" => "width=device-width, initial-scale=1"])));
		
		return $__v;
	}
	
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getComponentStyle(){ return ""; }
	static function getRequiredComponents(){ return new \Runtime\Vector(); }
	static function getClassName(){ return "App.Components.Blocks.Seo"; }
}