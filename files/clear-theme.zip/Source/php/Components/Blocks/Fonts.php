<?php
/*
 *  Fonts
*/
namespace App\Components\Blocks;


class Fonts extends \Runtime\Component
{
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getComponentStyle(){ return ""; }
	static function getRequiredComponents(){ return new \Runtime\Vector(); }
	static function getClassName(){ return "App.Components.Blocks.Fonts"; }
}