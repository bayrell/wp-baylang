<?php
/*
 *  CSS
*/
namespace App\Components\Blocks;

use Runtime\Widget\Button;
use Runtime\Widget\Form\Form;
use Runtime\Widget\TextArea;


class CSS extends \Runtime\Component
{
	/* ========= Class init functions ========= */
	function _init()
	{
		parent::_init();
	}
	static function getComponentStyle(){ return ":root{--widget-font-family: Arial;--widget-font-size: 16px;--widget-color-link: blue}body, html{font-family: var(--widget-font-family);font-size: var(--widget-font-size);line-height: var(--widget-line-height);width: 100%;padding: 0;margin: 0}.page_title{font-size: 32px;margin: 0px;text-align: center}%(TextArea)widget_textarea{min-height: 200px}"; }
	static function getRequiredComponents(){ return new \Runtime\Vector("Runtime.Widget.Button", "Runtime.Widget.Form.Form", "Runtime.Widget.TextArea"); }
	static function getClassName(){ return "App.Components.Blocks.CSS"; }
}