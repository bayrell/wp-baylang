<?php
namespace App\Admin;


class ModuleDescription
{
	/**
	 * Returns module name
	 */
	static function getModuleName(){ return "App.Admin"; }
	
	
	/**
	 * Returns module version
	 */
	static function getModuleVersion(){ return "0.0.1"; }
	
	
	/**
	 * Returns required modules
	 * @return Map<string>
	 */
	static function requiredModules()
	{
		return new \Runtime\Map([
			"Runtime" => ">=0.12",
		]);
	}
	
	
	/**
	 * Returns enities
	 */
	static function entities()
	{
		return new \Runtime\Vector(
		);
	}
	
	
	/* ========= Class init functions ========= */
	function _init()
	{
	}
	static function getClassName(){ return "App.Admin.ModuleDescription"; }
	static function getMethodsList(){ return null; }
	static function getMethodInfoByName($field_name){ return null; }
}